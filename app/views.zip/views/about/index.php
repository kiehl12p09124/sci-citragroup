
    <h1>About Me</h1>
    <table cellspacing="0" border="1">
        <tr>
            <td>Nama</td>
            <td><?= $data['nama']; ?></td>
        </tr>
        <tr>
            <td>Umur</td>
            <td><?= $data['umur']; ?></td>
        </tr>
        <tr>
            <td>Hobi</td>
            <td><?= $data['hobi']; ?></td>
        </tr>
    </table>
